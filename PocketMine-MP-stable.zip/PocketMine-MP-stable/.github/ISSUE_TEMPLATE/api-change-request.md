---
name: API change request
about: Suggest a change, addition or removal to the plugin API
title: ''
labels: ''
assignees: ''

---

<!--- tell us what you want -->
## Description


<!--- explain why you want this and why it's a good idea -->
## Justification


<!--- (optional) describe alternative methods you've explored to achieve your goal -->
## Alternative methods
